# import and initialisation necessary moduls
import pygame as pg
from random import randrange as rr
from pygame.constants import K_DOWN, K_LEFT, K_PRINT, K_RIGHT, K_UP

from pygame.display import flip
from pygame.key import get_pressed

#game screen
pg.init()
sc_size = [810, 810]
gm_sc = pg.display.set_mode(sc_size)


#definition's
pink = (230, 50, 230)
ex_pink = (200, 30, 180)
red = (255, 0, 70)
dir = None
sn_hd = [sn_x, sn_y] =[41, 41]
sn_tl = [[41, 42], [41, 43], [41, 44]] 
ap_x = rr(1, 80)
ap_y = rr(1, 80)
sc = 0
sc_mp = 1
myfont = pg.font.SysFont('Arial', 30)
gm_ov = False

image = pg.image.load('PAIMON.png').convert_alpha()
sound1 = pg.mixer.Sound('13848-ehe-te-nandayo (online-audio-converter.com).wav')

FramePerSec = pg.time.Clock()

def pp(x, y, color):
      pg.draw.rect(gm_sc, color, pg.Rect(x * 10, y * 10, 10, 10))

#game cycle
run_Gm = True
while run_Gm:
    gm_sc.fill((0, 200, 200))
    gm_sc.blit(myfont.render("score:{}".format(sc), False, (200, 200, 200)),(475,5))
    for block in sn_tl:
        if sn_x == block[0] and sn_y == block[1]:
            print('PAIMON hates you')
            myfont = pg.font.SysFont('Arial', 40)
            sound1.play()
            gm_sc.blit(image, (0, 0))
            gm_sc.blit(myfont.render("EHE TE NANDAYO", False, (0, 0, 0)),(100,300))
            pg.display.update()
            gm_ov = True
    if gm_ov:
        continue


    # quit the game 
    for event in pg.event.get():         
        if event.type == pg.QUIT:
            run_Gm = False
        #keystrokes 
        if event.type == pg.KEYDOWN:
            if event.key == pg.K_UP:
                    dir = 'UP'
            if event.key == pg.K_DOWN:
                    dir = 'DOWN'
            if event.key == pg.K_RIGHT:
                    dir = 'RIGHT'
            if event.key == pg.K_LEFT:
                    dir = 'LEFT'


    #tail's movement
    sn_en = list(sn_tl[-1])
    if dir:
        i = len(sn_tl)
        while i > 1:
            sn_tl[i - 1] = list(sn_tl[i - 2])
            i = i - 1
        sn_tl[0] = list([sn_x, sn_y])


    #eat apple
    if sn_x == ap_x  and sn_y == ap_y:
        ap_x = rr(0, 81)
        ap_y = rr(0, 81)
        sn_tl.append(list(sn_en))
        sc_mp += 1
        sc += sc_mp

    
    
    #snake's movement
    if dir == 'UP':
        sn_y -= 1
    if dir == 'DOWN':
        sn_y += 1
    if dir == 'RIGHT':
        sn_x += 1
    if dir == 'LEFT':
        sn_x -= 1


    # TOR
    if sn_x > 81:
        sn_x = 0
    if sn_y > 81:
        sn_y = 0
    if sn_x < 0:
        sn_x = 81
    if sn_y < 0:
        sn_y = 81
    



    
    
    #apple & snake design
    pp(ap_x, ap_y, red)
    pp(sn_x, sn_y, pink)
    for tl in sn_tl:
        pp(tl[0], tl[1], ex_pink)
    
    

    pg.display.flip()

    FramePerSec.tick(10)
pg.quit()